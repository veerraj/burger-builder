import * as actionTypes from './actionTypes';
import axios from "../../axios-orders";

export const authStart = () => {
     return {
         type:actionTypes.AUTH_START
     }
}

export const authFail = (error) => {
    return {
        type:actionTypes.AUTH_FAIL,
        error:error
    }
}

export const authSuccess = (idToken,userId) => {
    return {
        type:actionTypes.AUTH_SUCCESS,
        idToken:idToken,
        userId:userId
    }
}

export const loggedOut = () =>{
     return {
         type:actionTypes.LOG_OUT
     }
}

export const tokenTimeout = (expiresIn) =>{
    return dispatch =>{
        setTimeout(() => {
            dispatch(loggedOut())
        }, expiresIn * 1000);
    }
}

export const auth = (email,password,isSignUp) => {
    return dispatch => {
         dispatch(authStart())
         const authData = {
             email:email,
             password:password,
             returnSecureToken:true
         }
         let url = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=AIzaSyCnSQ01sHoc-gvoZSmlWLORptfXMvT1-Xk';
         if(!isSignUp){
             url = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=AIzaSyCnSQ01sHoc-gvoZSmlWLORptfXMvT1-Xk';
         }
         axios
            .post(url, authData)
            .then((res) => {
                console.log(res);
                dispatch(authSuccess(res.data.idToken,res.data.localId));
                dispatch(tokenTimeout(res.data.expiresIn));
            })
            .catch((error) => {
                console.log(error.response.data.error);
                dispatch(authFail(error.response.data.error));
            });
    }
}

export const setAuthRedirectPath = (path) =>{
     return {
         type:actionTypes.SET_AUTH_REDIRECT,
         path:path
     }
}
